#!/usr/bin/env ruby
require_relative 'creature.rb'

class Troll < Creature
end

#include <stdio.h>

#include "perso.h"

void init_perso() {
	printf("init_perso\n");
}

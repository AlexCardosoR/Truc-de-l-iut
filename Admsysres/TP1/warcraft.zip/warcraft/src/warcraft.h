#ifndef WARCRAFT_H
#define WARCRAFT_H

typedef struct {
	int version;
} Warcraft;

#endif


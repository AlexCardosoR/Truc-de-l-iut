#ifndef VIDEO_H
#define VIDEO_H

typedef struct {
	int screen;
} Video;

void init_video();

#endif
